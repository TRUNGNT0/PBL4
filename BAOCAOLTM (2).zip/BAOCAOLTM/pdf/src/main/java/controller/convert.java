package controller;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.http.Part;
import model.BO.FileConversionService;

import model.bean.account;

@WebServlet("/ConvertPDFServlet")
@MultipartConfig
public class convert extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public convert() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	// Đảm bảo tên trường trong form là "pdfFile"
        Part filePart = request.getPart("pdfFile");  
        if (filePart == null) {
            response.getWriter().println("No file uploaded.");
            return;
        }
        
        String contentType = filePart.getContentType();
        if (!contentType.equals("application/pdf")) {
            response.getWriter().println("Please upload a PDF file.");
            return;
        }
        String fileName = getFileName(filePart);
        //xử lý
        InputStream fileContent = filePart.getInputStream();

        account account = (account) request.getSession().getAttribute("account");
        byte[] wordFile = FileConversionService.convertPdfToWord(fileContent,account.getUsername(),fileName);

        // Gửi lại file Word cho client dưới dạng download
        if (wordFile != null) {
            response.setContentType("application/msword");
            response.setHeader("Content-Disposition", "attachment; filename=converted.docx");

            try (OutputStream responseOut = response.getOutputStream()) {
                responseOut.write(wordFile);
                responseOut.flush();
            }
        } else {
            response.getWriter().println("File conversion failed.");
        }
    }
    private String getFileName(Part part) {
        String contentDisposition = part.getHeader("Content-Disposition");
        for (String cd : contentDisposition.split(";")) {
            if (cd.trim().startsWith("filename")) {
                return cd.substring(cd.indexOf('=') + 2, cd.length() - 1);
            }
        }
        return null;
    }
}
