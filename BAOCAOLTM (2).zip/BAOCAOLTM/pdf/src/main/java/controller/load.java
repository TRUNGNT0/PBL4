package controller;

import java.io.*;
import java.util.List;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.BO.FileListService;
import model.bean.account;

@WebServlet("/LoadFilesServlet")
public class load extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public load() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Lấy thông tin người dùng từ session
        account account = (account) request.getSession().getAttribute("account");

        // Đảm bảo rằng người dùng đã đăng nhập
        if (account == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // Gọi FileListService để lấy danh sách file
        List<String> fileList = FileListService.loadFileList(account.getUsername());

        request.setAttribute("fileList", fileList); 

        // Forward đến JSP để hiển thị
        request.getRequestDispatcher("info.jsp").forward(request, response);
    }
}
