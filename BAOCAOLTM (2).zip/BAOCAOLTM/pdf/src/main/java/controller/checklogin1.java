package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.BO.accountBO;
import model.bean.account;

@WebServlet("/CheckLoginServlet")
public class checklogin1 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public checklogin1() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("user");
        String password = request.getParameter("pass");

        // Kiểm tra tài khoản trong CSDL qua accountBO
        account a = accountBO.getAccount(username, password);

        if (a == null) {
            // Nếu không tìm thấy tài khoản hợp lệ, chuyển hướng về trang login.jsp
            response.sendRedirect("login.jsp");
        } else {
            // Nếu tài khoản hợp lệ, lưu thông tin người dùng vào session
            HttpSession session = request.getSession();
            session.setAttribute("account", a);

            // Chuyển hướng đến trang info.jsp
            response.sendRedirect("info.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Sử dụng doGet để xử lý luôn các request từ form đăng nhập
        doGet(request, response);
    }
}
