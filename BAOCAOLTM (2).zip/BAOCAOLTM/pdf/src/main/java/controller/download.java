package controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.BO.FileDownloadService;
import model.bean.account;

@WebServlet("/DownloadFileServlet")
public class download extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public download() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Lấy thông tin file từ request
        String fileName = request.getParameter("filename");
        account account = (account) request.getSession().getAttribute("account");

        // Kiểm tra nếu người dùng không đăng nhập
        if (account == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // Gọi FileDownloadService để tải file
        byte[] fileData = FileDownloadService.downloadFile(account.getUsername(), fileName);

        if (fileData != null) {
            response.setContentType("application/msword");
            response.setHeader("Content-Disposition", "attachment;filename=" + fileName);

            // Gửi file về cho client
            try (OutputStream outStream = response.getOutputStream()) {
                outStream.write(fileData);
                outStream.flush();
            }
        } else {
            response.getWriter().println("File not found.");
        }
    }
}
