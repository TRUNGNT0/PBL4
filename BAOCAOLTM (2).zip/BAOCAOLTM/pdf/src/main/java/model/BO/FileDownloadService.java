package model.BO;

import java.io.*;
import java.net.Socket;

public class FileDownloadService {

    // Phương thức tải file về
    public static byte[] downloadFile(String username, String fileName) {
        byte[] fileData = null;

        try (Socket socket = new Socket("localhost", 7777);
             DataOutputStream outStream = new DataOutputStream(socket.getOutputStream());
             DataInputStream inStream = new DataInputStream(socket.getInputStream())) {

            // Gửi username cho server
            outStream.writeUTF(username);
            outStream.flush();

            // Gửi yêu cầu "download" cho server
            outStream.writeUTF("download");
            outStream.flush();

            // Gửi tên file cần tải
            outStream.writeUTF(fileName);
            outStream.flush();

            // Nhận file từ server
            fileData = receiveFileFromServer(inStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fileData;
    }

    // Nhận file từ server
    private static byte[] receiveFileFromServer(DataInputStream inStream) throws IOException {
        // Đọc kích thước của file từ server
        int fileLength = inStream.readInt();

        if (fileLength > 0) {
            byte[] fileData = new byte[fileLength];
            inStream.readFully(fileData); 
            return fileData;
        }

        return null; 
    }
}
