package model.BO;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class FileListService {

    // Phương thức tải danh sách các file đã tải của user
    public static List<String> loadFileList(String username) {
        List<String> fileList = new ArrayList<>();

        try (Socket socket = new Socket("localhost", 7777);
             DataOutputStream outStream = new DataOutputStream(socket.getOutputStream());
             DataInputStream inStream = new DataInputStream(socket.getInputStream())) {

            // Gửi username cho server
            outStream.writeUTF(username);
            outStream.flush();

            // Gửi yêu cầu "list_files" cho server
            outStream.writeUTF("list_files");
            outStream.flush();

            // Nhận danh sách file từ server
            String fileListStr = inStream.readUTF();
            if (!fileListStr.isEmpty()) {
                String[] files = fileListStr.split(",");
                for (String file : files) {
                    fileList.add(file);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fileList;
    }
}
