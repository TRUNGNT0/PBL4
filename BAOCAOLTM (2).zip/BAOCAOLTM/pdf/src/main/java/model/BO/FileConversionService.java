package model.BO;

import java.io.*;
import java.net.Socket;

public class FileConversionService {

    public static byte[] convertPdfToWord(InputStream pdfFileContent, String username, String pdfFileName) {
        byte[] wordFile = null;

        try (Socket socket = new Socket("localhost", 7777);
             DataOutputStream outStream = new DataOutputStream(socket.getOutputStream());
             DataInputStream inStream = new DataInputStream(socket.getInputStream())) {

            // Gửi username cho server
            outStream.writeUTF(username);
            outStream.flush();

            
            outStream.writeUTF("convert");
            outStream.flush();

            
            outStream.writeUTF(pdfFileName); 
            outStream.flush();

            // Chuyển nội dung file PDF thành byte array
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = pdfFileContent.read(buffer)) != -1) {
                baos.write(buffer, 0, bytesRead);
            }
            byte[] pdfBytes = baos.toByteArray();
            baos.close();

            
            outStream.writeInt(pdfBytes.length);
            outStream.flush();

            
            outStream.write(pdfBytes);
            outStream.flush();

            // Nhận file Word từ server (bao gồm tên file và nội dung file)
            wordFile = receiveFileFromServer(inStream);
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return wordFile;
    }

    
    private static byte[] receiveFileFromServer(DataInputStream inStream) throws IOException {
        
        String wordFileName = inStream.readUTF();  

        
        int fileLength = inStream.readInt(); 

        if (fileLength > 0) {
            byte[] wordFile = new byte[fileLength];
            inStream.readFully(wordFile); 

            
            System.out.println("Received Word file: " + wordFileName);

            return wordFile;
        }

        return null; // Nếu không có file hoặc gặp lỗi
    }
}
