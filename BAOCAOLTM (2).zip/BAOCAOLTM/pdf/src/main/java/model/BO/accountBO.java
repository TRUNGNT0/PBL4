package model.BO;

import model.bean.account;
import model.DAO.accountDAO;

public class accountBO {

	public static account getAccount(String username, String password) {
		return accountDAO.getAccount(username,password);
	}

}
