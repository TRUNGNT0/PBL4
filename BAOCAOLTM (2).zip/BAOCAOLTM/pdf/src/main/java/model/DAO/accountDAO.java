package model.DAO;

import java.sql.Connection;
import connectDB.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.bean.account;

public class accountDAO {

    public static account getAccount(String username, String password) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DBConnection.getConnection();
            String query = "SELECT * FROM accounts WHERE username = ? AND password = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                account acc = new account();
                acc.setUsername(resultSet.getString("username"));
                acc.setPassword(resultSet.getString("password"));
                acc.setName(resultSet.getString("name"));
                acc.setPos(resultSet.getString("position"));
                acc.setSalary(resultSet.getInt("salary"));
                return acc;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
