package baitaplon.convert;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class PDFToWordConverter {

    public static File convertPdfToWord(File pdfFile) {
        File wordFile = null;
        try (PDDocument pdfDoc = PDDocument.load(pdfFile);
             XWPFDocument wordDoc = new XWPFDocument()) {

            if (pdfDoc.isEncrypted()) {
                System.err.println("PDF bị mã hóa, không thể chuyển đổi.");
                return null;
            }

            // Trích xuất văn bản từ PDF
            PDFTextStripper pdfStripper = new PDFTextStripper();
            String text = pdfStripper.getText(pdfDoc);

            // Ghi văn bản vào file Word
            XWPFParagraph paragraph = wordDoc.createParagraph();
            paragraph.createRun().setText(text);

            // Lưu file Word tạm
            wordFile = File.createTempFile("output", ".docx");
            try (FileOutputStream fos = new FileOutputStream(wordFile)) {
                wordDoc.write(fos);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return wordFile;
    }
}
