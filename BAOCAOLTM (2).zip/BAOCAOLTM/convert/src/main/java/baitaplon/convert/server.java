package baitaplon.convert;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.*;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class server {
    private static final BlockingQueue<Socket> queue = new LinkedBlockingQueue<>();

    public static void main(String[] args) {
        System.out.println("Server running");

        for (int i = 0; i < 4; i++) {
            new Thread(new ConvertWorker(queue)).start();
        }

        try (ServerSocket serverSocket = new ServerSocket(7777)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Connection from: " + clientSocket.getInetAddress());
                queue.put(clientSocket);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class ConvertWorker implements Runnable {
    private final BlockingQueue<Socket> queue;

    public ConvertWorker(BlockingQueue<Socket> queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Socket socket = queue.take();
                handleClient(socket);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void handleClient(Socket socket) throws IOException {
        try (DataInputStream dis = new DataInputStream(socket.getInputStream());
             DataOutputStream dos = new DataOutputStream(socket.getOutputStream())) {

            String username = dis.readUTF(); // Nhận username từ client
            System.out.println("User: " + username);

            Path userDir = Paths.get("uploads", username);
            Files.createDirectories(userDir); // Tạo thư mục nếu chưa có

            String command = dis.readUTF(); // Nhận yêu cầu từ client

            switch (command) {
                case "download":
                    sendFile(dis, dos, userDir);
                    break;
                case "list_files":
                    listFiles(dos, userDir);
                    break;
                case "convert":
                    convertFile(dis, dos, userDir);
                    break;
                default:
                    dos.writeUTF("Invalid command");
                    break;
            }
        } finally {
            socket.close();
        }
    }

    private void sendFile(DataInputStream dis, DataOutputStream dos, Path userDir) throws IOException {
        String fileName = dis.readUTF(); // Nhận tên file từ client
        Path filePath = userDir.resolve(fileName);

        if (Files.exists(filePath)) {
            byte[] fileData = Files.readAllBytes(filePath);
            dos.writeInt(fileData.length);
            dos.write(fileData);
        } else {
            dos.writeInt(0); // Thông báo file không tồn tại
        }
    }

    private void listFiles(DataOutputStream dos, Path userDir) throws IOException {
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(userDir)) {
            StringBuilder fileList = new StringBuilder();
            for (Path file : stream) {
                fileList.append(file.getFileName()).append(",");
            }
            dos.writeUTF(fileList.length() > 0 ? fileList.substring(0, fileList.length() - 1) : "");
        }
    }

    private void convertFile(DataInputStream dis, DataOutputStream dos, Path userDir) throws IOException {
        
        String pdfFileName = dis.readUTF(); 
        int fileLength = dis.readInt();
        
        
        byte[] pdfData = new byte[fileLength];
        dis.readFully(pdfData);

        // Tạo file PDF tạm thời với tên giống tên file gốc của client
        File tempPdfFile = new File(userDir.toFile(), pdfFileName); 
        try (FileOutputStream fos = new FileOutputStream(tempPdfFile)) {
            fos.write(pdfData);
        }

        
        File tempWordFile = PDFToWordConverter.convertPdfToWord(tempPdfFile);

        if (tempWordFile != null) {
            // Đặt tên file Word giống tên file gốc của client (chỉ đổi phần mở rộng)
            String wordFileName = pdfFileName.replace(".pdf", ".docx");
            Path wordFilePath = userDir.resolve(wordFileName);
            
            // Di chuyển file Word sang thư mục người dùng
            Files.move(tempWordFile.toPath(), wordFilePath, StandardCopyOption.REPLACE_EXISTING);

         // Gửi client
            dos.writeUTF(wordFilePath.getFileName().toString());

            
            byte[] wordFileData = Files.readAllBytes(wordFilePath);
            dos.writeInt(wordFileData.length); 
            dos.write(wordFileData); 
        } else {
            dos.writeUTF("Convert failed");
        }

        
        tempPdfFile.delete();
    }

}
